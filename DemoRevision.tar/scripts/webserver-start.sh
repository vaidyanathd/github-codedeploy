#!/bin/bash

/etc/init.d/httpd start
